import pygame #Impordib Pygame'i mooduli.
import sys # Impordib süsteemi mooduli, mida kasutatakse süsteemiürituste (näiteks programmi sulgemise) käsitlemiseks.

pygame.init() #Initsialiseerib Pygame'i.

# Akna suurus
screen = pygame.display.set_mode((640, 480)) #pygame.display.set_mode((640, 480)): Loob akna suurusega 640x480 pikslit.
pygame.display.set_caption("Ülesanne 2") #Seab akna pealkirja "Ülesanne 2".

# Taust
bg_shop = pygame.image.load("bg_shop.png") #Laeb taustapildi failist "bg_shop.png".

# Müüja
seller = pygame.image.load("seller.png") #Laeb müüja pildi failist "seller.png".
seller = pygame.transform.scale(seller, [220, 310]) #Muudab müüja pildi mõõtmeid, et see oleks suurem (220x310 pikslit).

# Chat kast
chat = pygame.image.load("chat.png") #Laeb chat-kasti pildi failist "chat.png".
chat = pygame.transform.scale(chat, [255, 210]) #Muudab chat-kasti pildi mõõtmeid, et see oleks suurem (255x210 pikslit).

#font ja suurus
font = pygame.font.SysFont("Tahoma", 19) #Seab fondi nimeks "Tahoma" suurusega 19 punkti.

# Tekst chat kastis
text = "Tere, olen Andreas Soitu" #Määrab teksti, mis kuvatakse chat-kastis.

running = True #Kui running on tõene.
while running: #Algab lõpmatu tsükkel, mis töötab seni, kuni muutuja running väärtus muutub False-ks.
    for event in pygame.event.get(): #Kontrollib kõiki Pygame'i sündmusi.
        if event.type == pygame.QUIT: #: Kui kasutaja sulgeb akna, muudetakse muutuja running väärtus False-ks, lõpetades tsükli.
            running = False #Running on väär.

    # Kuvab taustapildi (0, 0) asukohast alates
    screen.blit(bg_shop, (0, 0)) # Kuvab taustapildi koordinaatidel (0, 0).
    screen.blit(seller, [108, 160]) #Kuvab müüja pildi koordinaatidel (108, 160).
    screen.blit(chat, [246, 65]) #Kuvab chat-kasti koordinaatidel (246, 65).

    # Kuvab teksti
    text_surface = font.render(text, True, (255, 255, 255)) #Loob teksti pinnale, kasutades eelnevalt määratud teksti, fonti ja värvi (valge).
    text_rect = text_surface.get_rect(center=(370, 163)) #Määrab tekstile ala, keskmes koordinaatidel (370, 163).
    screen.blit(text_surface, text_rect.topleft) #Kuvab tekstile vastava pildi koordinaatidel, mis on määratud eelnevalt.

    # Uuenda ekraan
    pygame.display.flip() #Värskendab ekraani.

pygame.quit() #Lõpetab Pygame'i.
sys.exit() #Lõpetab süsteemi ja sulgeb programmi.
