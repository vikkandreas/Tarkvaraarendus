import pygame # Impordib Pygame'i mooduli.
pygame.init() #  Initsialiseerib Pygame'i.

# Ekraani seaded
screen = pygame.display.set_mode([300, 300]) # Loob ekraani suurusega 300x300 pikslit ja määrab selle muutujasse screen.
pygame.display.set_caption("Ülesanne1/lumememm - Andreas Soitu") #Määrab akna pealkirjaks "Ülesanne1/lumememm - Andreas Soitu".
screen.fill([0, 0, 0]) #Täidab ekraani musta värviga, luues musta tausta.

# Joonistamine - Joonistab kolm ringi, mis moodustavad lumememme keha, pead ja aluse, kasutades pygame.draw.circle() funktsiooni.
pygame.draw.circle(screen, [255, 255, 255], [150, 75], 30)
pygame.draw.circle(screen, [255, 255, 255], [150, 140], 40) 
pygame.draw.circle(screen, [255, 255, 255], [150, 225], 50)

# Silmad - Joonistab kaks musta silma, kasutades samuti pygame.draw.circle() funktsiooni.
pygame.draw.circle(screen, [0, 0, 0], [140, 70], 5)
pygame.draw.circle(screen, [0, 0, 0], [160, 70], 5)

# Nina 
pygame.draw.polygon(screen, (255, 0, 0), [[145, 80], [150, 95], [155, 80]]) # joonistab punase nina, kasutades pygame.draw.polygon() funktsiooni.

pygame.display.flip() # Värskendab ekraani, kuvades kõik eelnevalt joonistatud kujundid.

# Mängu tsükkel
running = True # Kui running on võrdne True
while running: #hoiab programmi töös, kuni kasutaja sulgeb akna.
    for event in pygame.event.get(): #Sündmuste loop jälgib aknas toimuvaid sündmusi.
        if event.type == pygame.QUIT: # See tingimus kontrollib, kas viimane sündmus, mida Pygame on kogunud, on akna sulgemissündmus (pygame.QUIT).
            running = False  #Kui kasutaja klõpsab akna sulgemisnuppu, muudab see muutuja running väärtuseks False, mis põhjustab mängutsükli lõppemise (while running: tsükli lõpetamine) ja programmi sulgemise.
    
    pygame.display.update() # See uuendab akent, kuvades kõik eelnevalt joonistatud kujundid või tekstid, mis võivad olla muutunud või on ekraanil peidetud. 

pygame.quit() # See sulgeb Pygame'i, vabastades kõik kasutatud ressursid ja sulgedes akna. Pärast seda funktsiooni väljakutsumist ei saa enam Pygame'i funktsioone kasutada.
