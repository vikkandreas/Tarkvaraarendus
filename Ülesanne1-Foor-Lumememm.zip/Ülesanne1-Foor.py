import pygame #See impordib Pygame'i mooduli, mis võimaldab meil kasutada Pygame'i funktsioone ja klassid.
pygame.init() #See käivitab Pygame'i ja valmistab selle kasutamiseks ette.
#ekraani seaded
screen=pygame.display.set_mode([300,300]) #See loob uue ekraani (akna) suurusega 300x300 pikslit ja määrab selle muutujasse 
pygame.display.set_caption("Ülesanne1/foor - Andreas Soitu") #See seab akna pealkirjaks "Ülesanne1/foor - Andreas Soitu".
screen.fill([0, 0, 0]) #See täidab ekraani musta värviga, luues musta tausta.

#joonistamine
pygame.draw.rect(screen, [128, 128, 128], [100, 15, 100, 270], 2)  #See joonistab halli (RGB väärtusega [128, 128, 128]) raami, mis esindab foori, koordinaatidega x=100, y=15, laiusega 100 ja kõrgusega 270 pikslit, paksusega 2 pikslit.
pygame.draw.circle(screen, [255, 0, 0], [150, 65], 40, 0) # See joonistab punase ringi (RGB väärtusega [255, 0, 0]) koordinaatidega x=150, y=65, raadiusega 40 pikslit ja täidab selle värvi, mitte ainult kontuuri.
pygame.draw.circle(screen, [255, 255, 0], [150, 150], 40, 0) # See joonistab kollase ringi (RGB väärtusega [255, 255, 0]) koordinaatidega x=150, y=150, raadiusega 40 pikslit ja täidab selle värvi, mitte ainult kontuuri.
pygame.draw.circle(screen, [0, 255, 0], [150, 235], 40, 0) # See joonistab rohelise ringi (RGB väärtusega [0, 255, 0]) koordinaatidega x=150, y=235, raadiusega 40 pikslit ja täidab selle värvi, mitte ainult kontuuri.

pygame.display.flip() #See uuendab ekraani, kuvades kõik eelnevalt joonistatud kujundid.
# Mängu tsükkel
running = True # See loob muutuja running ja seab selle väärtuseks True, et käivitada mängutsükkel.
while running: # See algatab mängutsükli, mis kestab seni, kuni running on True.
    for event in pygame.event.get(): #  See käivitab sündmuste loengu, et jälgida kasutaja toiminguid.
        if event.type == pygame.QUIT:  # Kontrollib, kas kasutaja on sulgemisnuppu klõpsanud
            running = False  # Lõpetab mängu tsükli ja sulgeb akna
    
    # Siia võid lisada muud mänguloogikat
    
    pygame.display.update() #funktsioon uuendab kogu akent.

pygame.quit()  # Lõpetab pygame'i kasutamise pärast mängu tsükli lõppu