import pygame #See käsk laeb Pygame'i teegi, mis võimaldab graafiliste rakenduste loomist.

def joonista_ruudustik(ruudu_suurus, read, veerud, joone_varv, joone_laius): #See on funktsioon, mis joonistab ruudustiku ekraanile. Parameetrid määravad ruutude suuruse, ridade ja veergude arvu, joone värvi ja joone laiuse.
    for i in range(read + 1): #See tsükkel käib läbi ridade arvu (read) pluss ühe ringi. See on seotud funktsiooniga pygame.draw.line mis joonistab joone igale reale.
        pygame.draw.line(ekraan, joone_varv, (0, i * ruudu_suurus), (640, i * ruudu_suurus), joone_laius) #See joonistab joone ekraanile. Parameetrid on: ekraan: Ekraan, kuhu joonistatakse. joone_varv: Joone värv, mis on antud tuple'ina RGB väärtustega.(0, i * ruudu_suurus): Joone alguspunkt, kus x-koordinaat on alati 0 ja y-koordinaat on i korda ruudu_suurus. (640, i * ruudu_suurus): Joone lõpp-punkt, kus x-koordinaat on alati 640 (ekraani laius) ja y-koordinaat on sama, mis alguspunkt, moodustades horisontaalse joone.joone_laius: Joone laius pikslites.
    for j in range(veerud + 1): #See tsükkel käib läbi veergude arvu (veerud) pluss ühe ringi. See on seotud funktsiooniga. 
        pygame.draw.line(ekraan, joone_varv, (j * ruudu_suurus, 0), (j * ruudu_suurus, 480), joone_laius) # See joonistab vertikaalsed jooned. Parameetrid on sarnased eelmistega, kuid nüüd x-koordinaat muutub vastavalt j korrutatuna ruudu_suurusega, ja y-koordinaadid moodustavad vertikaalse joone.

pygame.init() #See käivitab Pygame'i ja valmistab ette selle kasutamise.

ekraan = pygame.display.set_mode((640, 480)) #Loob akna (ekraani) mõõtmetega 640x480 pikslit.
pygame.display.set_caption("Ülesanne 3") #  Määrab akna pealkirja.

taust = pygame.Surface(ekraan.get_size()) #Loob taustapinna, mille suurus vastab ekraani suurusele.
taust.fill((152, 255, 159)) #Täidab taustapinna värviga (RGB: 152, 255, 159) - see on roheline värv.
taust = taust.convert() #Meetod teisendab pildipinna uude formaati, mis vastab ekraani formaadile.
ekraan.blit(taust, (0, 0))# Pygame'i funktsioon, mis kopeerib ühe pildipinna (surface) teisele. Selles konkreetses kohas kasutatakse seda selleks, et kopeerida taustapind (millele eelnevalt on joonistatud ruudustik) ekraanipinnale. (0, 0): See on koordinaat, kuhu taustapind kopeeritakse 

ruudu_suurus = input("Sisesta ruudu suurus: ") #Küsib kasutajalt ruudu suurust.
ruudu_suurus = 10 if not ruudu_suurus else int(ruudu_suurus) #if not ruudu_suurus: Kontrollib, kas muutuja ruudu_suurus on tühi (False) või null-väärtus. Kui ruudu_suurus pole tühi (kasutaja on midagi sisestanud), siis int(ruudu_suurus) muudab sisestatud teksti täisarvuks ja määrab selle väärtuse muutujale ruudu_suurus. Kui ruudu_suurus on tühi (kasutaja ei ole midagi sisestanud), siis kasutatakse vaikeväärtust 10.

punane = input("Sisesta punase kogus 0-255: ") #Kasutajalt küsitakse sisendit punase värvikomponendi jaoks vahemikus 0 kuni 255.
punane = 255 if not punane else int(punane) #Kasutatakse tingimuslauset, mis kontrollib, kas kasutaja sisestas midagi. Kui mitte, siis määratakse punase värvi vaikeväärtuseks 255; vastasel juhul teisendatakse sisend täisarvuks ja määratakse muutujale punane.

roheline = input("Sisesta rohelise kogus 0-255: ") #Kasutajalt küsitakse sisendit rohelise värvikomponendi jaoks vahemikus 0 kuni 255.
roheline = 0 if not roheline else int(roheline) #Kasutatakse tingimuslauset, mis kontrollib, kas kasutaja sisestas midagi. Kui mitte, siis määratakse rohelise värvi vaikeväärtuseks 0; vastasel juhul teisendatakse sisend täisarvuks ja määratakse muutujale roheline.

sinine = input("Sisesta sinise kogus 0-255: ") # Kasutajalt küsitakse sisendit sinise värvikomponendi jaoks vahemikus 0 kuni 255.
sinine = 0 if not sinine else int(sinine) # Kasutatakse tingimuslauset, mis kontrollib, kas kasutaja sisestas midagi. Kui mitte, siis määratakse sinise värvi vaikeväärtuseks 0; vastasel juhul teisendatakse sisend täisarvuks ja määratakse muutujale sinine.

read = input("Sisesta ridade arv: ") #Kasutajalt küsitakse sisendit
read = 10 if not read else int(read) #Kasutatakse tingimuslauset, et määrata vaikeväärtused (10), kui kasutaja midagi ei sisesta. Vastasel juhul teisendatakse sisend täisarvuks ja määratakse muutujatele 

veerud = input("Sisesta veergude arv: ") #Kasutajalt küsitakse sisendit
veerud = 10 if not veerud else int(veerud) #Kasutatakse tingimuslauset, et määrata vaikeväärtused (10), kui kasutaja midagi ei sisesta. Vastasel juhul teisendatakse sisend täisarvuks ja määratakse muutujatele 

joone_laius = input("Sisesta joone laius pikslites: ") #Kasutajalt küsitakse sisendit joone laiuse jaoks pikslites.
joone_laius = 2 if not joone_laius else int(joone_laius) #Kasutatakse tingimuslauset, et määrata vaikeväärtus (2), kui kasutaja midagi ei sisesta. Vastasel juhul teisendatakse sisend täisarvuks ja määratakse muutujale joone_laius.

jooksev = True # Mmuudab muutuja jooksev väärtuseks True,
while jooksev: #Lõpmatu tsükkel, mis töötab seni, kuni kasutaja sulgeb akna.
    for sündmus in pygame.event.get(): #Kontrollib Pygame sündmusi, eriti kasutaja poolt käivitatud sulgemise sündmust .
        if sündmus.type == pygame.QUIT: #See if-lause kontrollib, kas praegune sündmus on akna sulgemise sündmus (pygame.QUIT). Kui kasutaja on vajutanud akna sulgemise nuppu, siis see tingimus saab tõeseks (True).
            jooksev = False # Muudab muutuja jooksev väärtuseks False.

    joonista_ruudustik(ruudu_suurus, read, veerud, (punane, roheline, sinine), joone_laius) # See rida kutsutakse funktsiooni joonista_ruudustik, edastades talle parameetrid nagu ruudu suurus, ridade arv, veergude arv, joone värv (punane, roheline, sinine) ja joone laius.

    pygame.display.flip() #See käsk värskendab ekraani, näidates kõiki uusi graafilisi muudatusi, mis on tehtud pärast viimast värskendust. See on oluline, et kasutaja näeks ruudustiku joonistamist pärast funktsiooni joonista_ruudustik kutsumist.

pygame.quit() # See käsk sulgeb Pygame'i ja lõpetab programmi.
