#Animeermine
import pygame # Impordib Pygame teegi, mis pakub tööriistu mängude ja multimeediarakenduste loomiseks Pythonis.
import sys # Impordib sys-mooduli, mis annab juurdepääsu süsteemispetsiifilistele muutujaile ja funktsioonidele.
import random # Impordib random-mooduli, mis genereerib juhuslikke numbreid.

pygame.init() # Initsialiseerib Pygame ja seadistab selle moodulid.

screen = pygame.display.set_mode((640, 480)) # Loob akna eraldusvõimega 640x480 pikslit ja määrab selle screen-muutujale.
pygame.display.set_caption("Animeerimine") # Määrab akna pealkirjaks "Animeerimine".
clock = pygame.time.Clock() # Loob kellaobjekti, mida kasutatakse mängu kaadrisageduse juhtimiseks.

Score = 0 #  Initsialiseerib muutuja nimega Score väärtusele 0, mida kasutatakse mängija skoori jälgimiseks.

bg = pygame.image.load("bg_rally.jpg") #  Laadib taustapildi nimega "bg_rally.jpg".

f1_blue = pygame.image.load("f1_blue.png") #  Laadib pildi sinisest autost nimega "f1_blue.png".
f1_blue = pygame.transform.rotate(f1_blue, 180) #  Pöörab sinise auto pilti 180 kraadi.

f2_blue = pygame.image.load("f1_blue.png") # Laadib veel ühe koopia sinise auto pildist.
f2_blue = pygame.transform.rotate(f2_blue, 180) #  Pöörab teise sinise auto pilti 180 kraadi.

f1_red = pygame.image.load("f1_red.png") # Laadib pildi punasest autost nimega "f1_red.png".

BspeedY = 3 # Määrab siniste autode algse vertikaalse kiiruse 3 pikslit kaadri kohta.
BposY = random.randint(0, 100) # Initsialiseerib esimese sinise auto vertikaalse positsiooni juhusliku väärtusega vahemikus 0 kuni 100.
B2posY = random.randint(0, 100) # Initsialiseerib teise sinise auto vertikaalse positsiooni juhusliku väärtusega vahemikus 0 kuni 100.
RposX, RposY = 298, 390 #  Määrab punase auto algse horisontaalse ja vertikaalse positsiooni vastavalt 298 ja 390.
RspeedY = 0 #  Määrab punase auto algse vertikaalse kiiruse 0.
BposX = random.randint(130, 280) # Initsialiseerib esimese sinise auto horisontaalse positsiooni juhusliku väärtusega vahemikus 130 kuni 280.
B2posX = random.randint(300, 480) # Initsialiseerib teise sinise auto horisontaalse positsiooni juhusliku väärtusega vahemikus 300 kuni 480.

while True: #  Algatab lõpmatu tsükli, mis käivitab mängu pidevalt.
    clock.tick(120) # Piirab mängu kaadrisageduse 120 kaadrini sekundis.

    for event in pygame.event.get(): #  Käib läbi kõik sündmused, mis on toimunud pärast viimast kaadrit.
        if event.type == pygame.QUIT: # Kontrollib, kas sündmus on "sulge" sündmus (nt kasutaja sulges akna).
            sys.exit() # Sulgeb mängu, kui tuvastatakse "sulge" sündmus.

    screen.blit(bg, (0, 0)) # Joonistab taustapildi ekraanile positsioonil (0, 0).
    screen.blit(f1_blue, (BposX, BposY)) # Joonistab sinise auto pildi ekraanile positsioonile (BposX, BposY).
    screen.blit(f2_blue, (B2posX, B2posY)) # Joonistab teise sinise auto pildi ekraanile positsioonile (B2posX, B2posY).
    BposY += BspeedY / 2 # Liigutab sinist autot vertikaalselt allapoole kiirusega BspeedY / 2 pikslit kaadri kohta.
    B2posY += BspeedY / 2 #  Liigutab teist sinist autot vertikaalselt allapoole kiirusega BspeedY / 2 pikslit kaadri kohta.

    screen.blit(f1_red, (RposX, RposY)) # Joonistab punase auto pildi ekraanile positsioonile (RposX, RposY).
    RposY += RspeedY #  Liigutab punast autot vertikaalselt allapoole kiirusega RspeedY pikslit kaadri kohta.
    screen.blit(pygame.font.Font(None, 30).render(f"Score: {Score}", True, [255, 255, 255]), [10, 460]) # Joonistab ekraanile teksti "Score: {Score}" valge värviga positsioonile (10, 460).

    if BposY >= 480: # Kontrollib, kas sinine auto on jõudnud ekraani alumise servani.
        BposY = -120 # Kui jah, siis liigutab auto ekraani ülaossa.
        Score += 1 #  Lisab skoorile ühe punkti.
        BposX = random.randint(130, 280) # Annab sinise auto horisontaalsele positsioonile juhusliku väärtuse vahemikus 130 kuni 280.

    keys = pygame.key.get_pressed() #  Loeb klaviatuuril vajutatud klahvid.
    if keys[pygame.K_LEFT]: # Kui vasak nool on vajutatud, siis liigutab punast autot vasakule.
        RposX -= 5 #  Liigutab punast autot 5 pikslit vasakule.
        if RposX < 130: #  Kontrollib, kas punane auto on ekraani vasakust servast väljas.
            RposX = 130 # Kui jah, siis hoiab auto ekraani sees.
    if keys[pygame.K_RIGHT]: # Kui parem nool on vajutatud, siis liigutab punast autot paremale.
        RposX += 5 #  Liigutab punast autot 5 pikslit paremale.
        if RposX > 480 - 55: # Kontrollib, kas punane auto on ekraani paremast servast väljas.
            RposX = 480 - 55 # Kui jah, siis hoiab auto ekraani sees, seades selle horisontaalseks asukohaks 480 - 55 pikslit (55 pikslit vasakule ekraani servast).

    if B2posY >= 480: # Kontrollib, kas teine sinine auto on jõudnud ekraani alumise servani.
        B2posY = -120 # Kui jah, siis liigutab auto ekraani ülaossa positsioonile -120 pikslit.
        Score += 1 # Lisab skoorile ühe punkti.
        B2posX = random.randint(300, 480) # Annab teise sinise auto horisontaalsele positsioonile juhusliku väärtuse vahemikus 300 kuni 480 pikslit.

    if RposY >= 480: # Kontrollib, kas punane auto on jõudnud ekraani alumise servani.
        RposY = -120 #  Kui jah, siis liigutab auto ekraani ülaossa positsioonile -120 pikslit.

    if B2posY <= RposY + 58 and B2posY >= RposY - 58: # Kontrollib, kas teise sinise auto vertikaalne asukoht on punase autoga kokkupõrke ulatuses (58 pikslit üles ja alla punase auto vertikaalsest asukohast).
        if B2posX <= RposX + 55 and B2posX >= RposX - 55: # Kui jah, siis kontrollib ka horisontaalset asukohta (55 pikslit vasakule ja paremale punase auto horisontaalsest asukohast).
            B2posY = -120 # Kui ka horisontaalne asukoht on kokkupõrke ulatuses, siis liigutab teise sinise auto ekraani ülaossa.
            Score += 1 #  Lisab skoorile ühe punkti.

    if BposY <= RposY + 58 and BposY >= RposY - 58: #  Kontrollib, kas esimese sinise auto vertikaalne asukoht on punase autoga kokkupõrke ulatuses (58 pikslit üles ja alla punase auto vertikaalsest asukohast).
        if BposX <= RposX + 55 and BposX >= RposX - 55: # Kui jah, siis kontrollib ka horisontaalset asukohta (55 pikslit vasakule ja paremale punase auto horisontaalsest asukohast).
            BposY = -120 # Kui ka horisontaalne asukoht on kokkupõrke ulatuses, siis liigutab teise sinise auto ekraani ülaossa.
            Score += 1 #  Lisab skoorile ühe punkti.

    screen.blit(pygame.font.Font(None, 30).render(f"Speed: {BspeedY}", True, [255, 255, 255]), [10, 10]) # Joonistab ekraanile teksti "Speed: {BspeedY}" valge värviga koordinaatidele (10, 10), kus {BspeedY} näitab hetke kiirust.

    pygame.display.flip() #  Uuendab kogu ekraani, et kuvada kõik objektide liikumised ja muudatused, mis on tehtud alates viimasest värskendusest.
