import pygame
import sys

pygame.init()

# Akna suurus
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("Ülesanne 2")

# Taust
bg_shop = pygame.image.load("bg_shop.png")

# Müüja
seller = pygame.image.load("seller.png")
seller = pygame.transform.scale(seller, [220, 310])

# Chat kast
chat = pygame.image.load("chat.png")
chat = pygame.transform.scale(chat, [255, 210])

#font ja suurus
font = pygame.font.SysFont("Tahoma", 19)

# Tekst chat kastis
text = "Tere, olen Andreas Soitu"

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Kuvab taustapildi (0, 0) asukohast alates
    screen.blit(bg_shop, (0, 0))
    screen.blit(seller, [108, 160])
    screen.blit(chat, [246, 65])

    # Kuvab teksti
    text_surface = font.render(text, True, (255, 255, 255))
    text_rect = text_surface.get_rect(center=(370, 163))
    screen.blit(text_surface, text_rect.topleft)

    # Uuenda ekraan
    pygame.display.flip()

pygame.quit()
sys.exit()